﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
 
namespace PointLibrary
{ public static class PointExtended
    {
        public static Point HalfPoint(this Point p) => new Point(p.X/2,p.Y/2);

    }

    [DataContract]
   public class Point: ICloneable, IEquatable<Point>, IComparable<Point>, IInterface1
    {
        [DataMember]
        public double X { get; set; }
        [DataMember]
        public double Y { get; set; }
        public Point(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public Point() : this(0, 0) { }

    

        public bool OnAxes
        {
            get
            {
                if (X == 0 || Y == 0)
                    return true;
                return false;
            }
           
        }
      
        public int QuadrantNumber()
        {
            if (X > 0 && Y > 0) return 1;
            else if (X > 0 && Y < 0) return 4;
            else if (X < 0 && Y > 0) return 2;
            else if (X < 0 && Y < 0) return 3;
            else return 0;
        }
        public Point GetSymmetric( string ans, Point point1=null)
        {
            point1 = point1 ?? this;

            if (ans == "y")
            {
                return new Point(-X, Y);
            }
            else if (ans == "x")
            {
                return new Point(X, -Y);
            }
            else if (ans == "point")
            {
                var pointRes = new Point();
                pointRes.X = point1.X * 2 - X;
                pointRes.Y = point1.Y * 2 - Y;
                return pointRes;
            }
            else throw new ArgumentException();
           

        }

        public static double Distance(Point point1, Point point2)
        {
           // if (point1 is null || point2 is null) throw new ArgumentNullException();
            double distance = Math.Sqrt(Math.Pow((point2.X - point1.X), 2) + Math.Pow(( point2.Y- point1.Y), 2));
            return distance;
        }

        public static bool operator ==(Point a, Point b) =>
           (a is null && b is null) ? true :
           (a is null ^ b is null) ? false : (a.X == b.X && a.Y == b.Y) ? true : false;
        public static bool operator !=(Point a, Point b) =>
         (a == b) ? false : true;
        public static Point operator +(Point a, Point b) =>
            a is null || b is null ? throw new ArgumentException():
            new Point(a.X + b.X, a.Y + b.Y);
        public static Point operator -(Point a, Point b) =>
             a is null || b is null ? throw new ArgumentException() :
           new Point(a.X - b.X, a.Y - b.Y);
        public static Point operator *(Point a, Point b) =>
             a is null || b is null ? throw new ArgumentException() :
           new Point(a.X * b.X, a.Y * b.Y);

        public virtual double MultiPoint()
        {
            return this.X * this.Y;
        }
       
        /* public Point Addition(Point a,Point b)
         {
             Point c = new Point(a.x + b.x, a.y + b.y);
             return c;
         }

         public Point Subtraction(Point a, Point b)
         {
             Point c = new Point(a.x - b.x, a.y - b.y);
             return c;
         }

         public Point Multiplication(Point a, Point b)
         {
             Point c = new Point(a.x * b.x, a.y * b.y);
             return c;
         }*/

        public override string ToString()=> $"{this.GetType().Name}({X};{Y})";

        public object Clone() => new Point(X, Y);

        public bool Equals(Point other) => X == other?.X && Y == other?.Y;

        public override bool Equals(object obj)
        {if(obj is Point a)
            {
                return Equals(a);
            }
            return false;
        }

        public int CompareTo(Point other)
        {
            if (this == other)
                return 0;
            return (other.X + other.Y > this.X + this.Y) ? -1 : 1;
             
        }
    }


}
