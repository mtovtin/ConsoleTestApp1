﻿using System;
using System.Collections.Generic;
using System.Text;
using PointLibrary;

namespace ConsoleTestApp
{
    class ThreeDimensionalPoint: Point
    {
        public double Z { get; set; }
        public ThreeDimensionalPoint(double X, double Y,double Z) :base(X,Y)
        {
            this.Z = Z;
        }
        public override string ToString() => $"{this.GetType().Name}({X};{Y};{Z})";
        public override double MultiPoint()
        {
            return this.X * this.Y * this.Z;
        }
         
        

    }
}
