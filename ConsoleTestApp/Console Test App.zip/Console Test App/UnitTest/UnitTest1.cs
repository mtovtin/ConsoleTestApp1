using PointLibrary;
using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ConstructorTest1()
        {
            var p = new Point(5, 6);
            Assert.IsTrue((p.X, p.Y) == (5, 6));
        }

        [TestMethod]
        public void ConstructorTest2()
        {
            var p = new Point();
            Assert.IsTrue((p.X, p.Y) == (0, 0));
        }

        [TestMethod]
        public void QuadrantNumberTest1()
        {
            var p = new Point();
            Assert.IsTrue(p.QuadrantNumber() == 0);
        }
        [TestMethod]
        public void QuadrantNumberTest2()
        {
            var p = new Point(3.55567,8.4938278819);
            Assert.IsTrue(p.QuadrantNumber() == 1);
        }
        [TestMethod]
        public void QuadrantNumberTest3()
        {
            var p = new Point(-3.55567, 8.4938278819);
            Assert.IsTrue(p.QuadrantNumber() == 2);
        }
        [TestMethod]
        public void QuadrantNumberTest4()
        {
            var p = new Point(-3.55567, -8.4938278819);
            Assert.IsTrue(p.QuadrantNumber() == 3);
        }
        [TestMethod]
        public void QuadrantNumberTest5()
        {
            var p = new Point(3.55567, -8.4938278819);
            Assert.IsTrue(p.QuadrantNumber() == 4);
        }

        [TestMethod]
        public void OnAxesTest1()
        {
            var p = new Point();
            Assert.IsTrue(p.OnAxes == true);
        }

        [TestMethod]
        public void OnAxesTest2()
        {
            var p = new Point(1,0);
            Assert.IsTrue(p.OnAxes == true);
        }

        [TestMethod]
        public void OnAxesTest3()
        {
            var p = new Point(0,-19);
            Assert.IsTrue(p.OnAxes == true);
        }
        [TestMethod]
        public void OnAxesTest4()
        {
            var p = new Point(Double.MaxValue,Double.MinValue);
            Assert.IsTrue(p.OnAxes == false);
        }

        [TestMethod]
        public void GetSymmetricTest1()
        {
            var p = new Point(10298374829.5, 18);
            Assert.AreEqual(p.GetSymmetric("x", null), new Point(10298374829.5, -18));
        }
        [TestMethod]
        public void GetSymmetricTest2()
        {
            var p = new Point(10298374829.5, 18);
            Assert.AreEqual(p.GetSymmetric( "y", null), new Point(-10298374829.5, 18));
        }
        [TestMethod]
        public void GetSymmetricTest3()
        {
            var p = new Point(10298374829.5, 18);
            Assert.AreEqual(p.GetSymmetric("point", null), new Point(10298374829.5, 18));
        }
        [TestMethod]
        public void GetSymmetricTest4()
        {
            var p = new Point(10298374829.5, 18);
            Assert.AreEqual(p.GetSymmetric( "point",new Point(12, 135)) ,new Point(-10298374805.5, 252));
        }
        [TestMethod]
        public void GetSymmetricTest5()
        {
            var p = new Point(10298374829.5, 18);
            Assert.ThrowsException<ArgumentException>(() => p.GetSymmetric("dgdfg", new Point(12, 135)));
        }
       
        [TestMethod]
        public void OperationsTest1()
        {
            var p = new Point(double.MaxValue, double.MaxValue);
            var n = new Point(0, 0);
            Assert.AreEqual((p+n),new Point(double.MaxValue, double.MaxValue));
        }
        [TestMethod]
        public void OperationsTest2()
        {
            var p = new Point(double.MinValue, double.MinValue);
            var n = new Point(0, 0);
            Assert.AreEqual((p + n), new Point(double.MinValue, double.MinValue));
        }
        [TestMethod]
        public void OperationsTest3()
        {
            var p = new Point(24, 0);
            var n = new Point(10, 5);
            Assert.AreEqual((p + n), new Point(34, 5));
        }
        
    
        [TestMethod]
        public void OperationsTest4()
        {
            var p = new Point(double.MaxValue, double.MaxValue);
            var n = new Point(0, 0);
            Assert.AreEqual((p - n), new Point(double.MaxValue, double.MaxValue));
        }
        [TestMethod]
        public void OperationsTest5()
        {
            var p = new Point(double.MinValue, double.MinValue);
            var n = new Point(0, 0);
            Assert.AreEqual((p - n), new Point(double.MinValue, double.MinValue));
        }
        [TestMethod]
        public void OperationsTest6()
        {
            var p = new Point(24, 0);
            var n = new Point(10, 5);
            Assert.AreEqual((p - n), new Point(14, -5));
        }
        [TestMethod]
        public void OperationsTest7()
        {
            var p = new Point(double.MaxValue, double.MaxValue);
            var n = new Point(1, 1);
            Assert.AreEqual((p * n), new Point(double.MaxValue, double.MaxValue));
        }
        [TestMethod]
        public void OperationsTest8()
        {
            var p = new Point(double.MinValue, double.MinValue);
            var n = new Point(1, 1);
            Assert.AreEqual((p * n), new Point(double.MinValue, double.MinValue));
        }
        [TestMethod]
        public void OperationsTest9()
        {
            var p = new Point(24, 0);
            var n = new Point(10, 5);
            Assert.AreEqual((p * n), new Point(240, 0));
        }

        [TestMethod]
        public void DistanceTest1()
        {
            var p = new Point(-7, -4);
            var n = new Point(-7, -4);
            Assert.AreEqual((Point.Distance(p, n)), 0);
        }

        [TestMethod]
        public void CloneTest1()
        {
            var p = new Point(-7, -4);
            var n = (Point)p.Clone();
            Assert.AreEqual((n), new Point(-7,-4));
        }
        [TestMethod]
        public void CloneTest2()
        {
            var p = new Point(double.MaxValue, double.MaxValue);
            var n = (Point)p.Clone();
            Assert.AreEqual((n), new Point(double.MaxValue, double.MaxValue));
        }
        [TestMethod]
        public void CloneTest3()
        {
            var p = new Point(double.MinValue, double.MinValue);
            var n = (Point)p.Clone();
            Assert.AreEqual((n), new Point(double.MinValue, double.MinValue));
        }
        [TestMethod]
        public void EqualsTest1()
        {
            var p = new Point(double.MinValue, double.MinValue);
       
            Assert.AreEqual((true),p.Equals(new Point(double.MinValue, double.MinValue)));
        }
        [TestMethod]
        public void EqualsTest2()
        {
            var p = new Point(double.MaxValue, double.MaxValue);

            Assert.AreEqual((true), p.Equals(new Point(double.MaxValue, double.MaxValue)));
        }
        [TestMethod]
        public void EqualsTest3()
        {
            var p = new Point(1, 2);

            Assert.AreEqual((true), p.Equals(new Point(1, 2)));
        }
        [TestMethod]
        public void EqualsTest4()
        {
            var p = new Point(double.MaxValue, double.MaxValue);

            Assert.AreEqual((false), p.Equals(null));
        }
        [TestMethod]
        public void EqualsTest5()
        {
            var p = new Point(double.MaxValue, double.MaxValue);

            Assert.AreEqual((false), p.Equals("123456"));
        }

        [TestMethod]
        public void CompareToTest1()
        {
            var p = new Point(double.MinValue, double.MinValue);
            var n = p;

            Assert.AreEqual((0), p.CompareTo(n));
        }
        [TestMethod]
        public void CompareToTest2()
        {
            var p = new Point(double.MaxValue, double.MaxValue);

            Assert.AreEqual((0), p.CompareTo(new Point(double.MaxValue, double.MaxValue)));
        }
 
        [TestMethod]
        public void CompareToTest3()
        {
            var p = new Point(double.MaxValue, double.MaxValue);

            Assert.ThrowsException<NullReferenceException>(() => p.CompareTo(null));
        }

        [TestMethod]
        public void CompareToTest4()
        {
            var p = new Point(5, 10);
            var n = new Point(-8, 22);
            Assert.AreEqual((1), p.CompareTo(n));
        }


        [TestMethod]
        public void CompareToTest5()
        {
            var n = new Point(5, 10);
            var p = new Point(-8, 22);
            Assert.AreEqual((-1), p.CompareTo(n),delta:1e-3);
        }
        [TestMethod]
        public void DistanceTest2()
        {
            var p = new Point(-7, -4);
            var n = new Point(17, 6.5);
            Assert.AreEqual((Point.Distance(p, n)), 26.1963737948595, delta:1e-3);
        }

        [TestMethod]
        public void HalfPointTest1()
        {
            var p = new Point(double.MaxValue, double.MinValue);
            Assert.AreEqual(new Point(double.MaxValue/2,double.MinValue/2), p.HalfPoint());
        }
        [TestMethod]
        public void MultiplicationTest1()
        {
            var p = new Point(int.MaxValue, 1);
            Assert.AreEqual(int.MaxValue, p.MultiPoint());
        }



        /* [TestMethod]
         public void Distance2()
         {
             var p = new Point(double.MaxValue, double.MaxValue);
             var n = new Point(0,0);
             Assert.AreEqual((Point.Distance(p, n)), double.MaxValue);
         }
         [TestMethod]
         public void Distance3()
         {
             var p = new Point(double.MinValue / 2, double.MinValue / 2);
             var n = new Point(0, 0);
             Assert.AreEqual((Point.Distance(p, n)), double.MinValue);
         }
         [TestMethod]
         public void Distance4()
         {
             var p = new Point(double.MaxValue / 2, double.MaxValue / 2);
             var n = new Point(1, 1);
             Assert.AreEqual((Point.Distance(p, n)), double.MinValue);
         }*/
        /*[TestMethod]
         public void ConstructorTest3()
         {
             var p = new Point();
             Assert.ThrowsException<ArgumentException>(()=>new Point(5,6));
         }
         
         
        [TestMethod]
        public void DistanceTest1()
        {
            var p = new Point(-7, -4);
            var n = new Point(17, 6.5);
            Assert.AreEqual((Point.Distance(p,n)), 26.1963737948595);
        }
         */
    }
}
